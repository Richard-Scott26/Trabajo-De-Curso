﻿using Proyecto.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.AppCore.Interfaces
{
    public interface IPassengerEmployeeServices : IServices<PassengerEmployee>
    {
        List<PassengerEmployee> FindByEmployeeId(int EmployeeId);
        List<PassengerEmployee> FindByPassengerId(int PassengerId);
        PassengerEmployee FindByPassengerEmployeeId(int EmployeeId, int PassengerId);
    }
}
