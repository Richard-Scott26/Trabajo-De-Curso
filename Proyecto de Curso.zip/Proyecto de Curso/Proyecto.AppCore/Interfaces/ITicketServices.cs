﻿using Proyecto.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.AppCore.Interfaces
{
    public interface ITicketServices : IServices<Ticket>
    {
        Ticket FindByCode(String code);
        List<Ticket> FindByDate(DateTime date);
    }
}
