﻿using Proyecto.AppCore.Interfaces;
using Proyecto.Domain.Entities;
using Proyecto.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.AppCore.Services
{
    public class PassengerService : Base<Passenger>, IPassengerServices
    {
        IPassengersModel model;

        public PassengerService(IPassengersModel model): base(model)
        {
            this.model = model;
        }
        public float AmountToPayBySuitcases(Passenger passenger)
        {
            return model.AmountToPayBySuitcases(passenger);
        }

        public Passenger FindById(int id)
        {
            return model.FindById(id);
        }

        public List<Passenger> FindByName(string name)
        {
            return model.FindByName(name);
        }

        public float PriceOfFligth(Fligth fligth)
        {
            return model.PriceOfFligth(fligth);
        }
    }
}
