﻿using Proyecto.AppCore.Interfaces;
using Proyecto.Domain.Entities;
using Proyecto.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.AppCore.Services
{
    public class EmployeeService : Base<Employee>, IEmployeeServices
    {
        IEmployeeModel model;
        public EmployeeService(IEmployeeModel model) : base(model)
        {
            this.model = model;
        }
        public Employee FindById(int id)
        {
            return model.FindById(id);
        }

        public List<Employee> FindByName(string name)
        {
            return model.FindByName(name);
        }
    }
}
