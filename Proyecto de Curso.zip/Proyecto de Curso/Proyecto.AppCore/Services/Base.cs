﻿using Proyecto.AppCore.Interfaces;
using Proyecto.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.AppCore.Services
{
    public class Base<T> : IServices<T>
    {
        IModel<T> model;

        public Base(IModel<T> mode)
        {
            this.model = model;
        }
        public void Create(T t)
        {
            model.Create(t);
        }

        public bool Delete(T t)
        {
            return model.Delete(t);
        }

        public List<T> Read()
        {
            return model.Read();
        }

        public bool Update(T t)
        {
            return model.Update(t);
        }
    }
}
