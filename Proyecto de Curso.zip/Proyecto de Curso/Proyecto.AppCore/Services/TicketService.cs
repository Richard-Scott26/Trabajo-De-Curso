﻿using Proyecto.AppCore.Interfaces;
using Proyecto.Domain.Entities;
using Proyecto.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.AppCore.Services
{
    public class TicketService : Base<Ticket>, ITicketServices
    {
        ITicketModel model;
        public TicketService(ITicketModel model) : base(model)
        {
            this.model = model;
        }
        public Ticket FindByCode(string code)
        {
            return model.FindByCode(code);
        }

        public List<Ticket> FindByDate(DateTime date)
        {
            return model.FindByDate(date);
        }
    }
}
