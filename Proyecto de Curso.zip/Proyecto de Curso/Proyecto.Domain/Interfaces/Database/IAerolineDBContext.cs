﻿using Microsoft.EntityFrameworkCore;
using Proyecto.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Proyecto.Domain.Interfaces
{
    public interface IAerolineDBContext
    {
        public DbSet<Passenger> Passengers { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<PassengerEmployee> PassengersEmployees { get; set; }

        public int SaveChanges();
        public Task<int> SaveChangesAsync(CancellationToken cancellationToken);
    }
}
