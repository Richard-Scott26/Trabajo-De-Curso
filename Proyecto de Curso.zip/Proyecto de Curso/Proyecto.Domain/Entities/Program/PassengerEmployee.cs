﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Proyecto.Domain.Entities
{
    public partial class PassengerEmployee
    {
        public int Id { get; set; }
        public int IdPassenger { get; set; }
        public int IdEmployee { get; set; }
        public bool IsActive { get; set; }
        public int IdPassengerkey { get; set; }
        public int IdEmployeekey { get; set; }

        public virtual Employee IdEmployeekeyNavigation { get; set; }
        public virtual Passenger IdPassengerkeyNavigation { get; set; }
    }
}
