﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Proyecto.Domain.Entities
{
    public partial class Person
    {
        public Person()
        {
            Employees = new HashSet<Employee>();
            Passengers = new HashSet<Passenger>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Lastname { get; set; }
        public int Age { get; set; }
        public string CivilState { get; set; }
        public string Gener { get; set; }
        public string Telephone { get; set; }
        public string Email { get; set; }
        public string CardId { get; set; }
        public DateTime Datetime { get; set; }

        public virtual ICollection<Employee> Employees { get; set; }
        public virtual ICollection<Passenger> Passengers { get; set; }
    }
}
